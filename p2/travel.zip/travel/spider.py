# coding=utf-8
'''
Created on 2015年4月23日
旅游信息的爬虫,直接用浏览器浏览
@author: Administrator
'''
if __name__ == '__main__':
    import utils
    utils.getdata()
